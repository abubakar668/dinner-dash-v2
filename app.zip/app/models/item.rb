# frozen_string_literal: true

class Item < ApplicationRecord
  belongs_to :restaurant

  has_many :item_categories, dependent: :destroy
  has_many :categories, through: :item_categories
  has_many :order_items, dependent: :destroy
  has_many :cart_items, dependent: :destroy
  has_one_attached :image

  validates :title, presence: true, uniqueness: true
  validates :description, presence: true
  validates :price, presence: true, numericality: { greater_than: 0 }
  #validates :category_ids, presence: true
end
