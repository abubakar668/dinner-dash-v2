# frozen_string_literal: true

class Restaurant < ApplicationRecord
  has_many :items, dependent: :destroy
  has_one_attached :image

  validates :name, presence: true, uniqueness: true
  validates :description, presence: true
end
