# frozen_string_literal: true

class CartItem < ApplicationRecord
  belongs_to :item
  belongs_to :cart

  before_save :set_unit_price
  before_save :set_total

  validates :quantity, presence: true, numericality: { greater_than: 0 }
  validates :total, presence: true, numericality: { greater_than: 0 }
  validates :unit_price, presence: true, numericality: { greater_than: 0 }
  validates :item_id, presence: true
  validates :cart_id, presence: true

  def unit_price
    persisted? ? self[:unit_price] : item.price
  end

  def total
    unit_price * quantity
  end

  private

  def set_unit_price
    self.unit_price = unit_price
  end

  def set_total
    self.total = total
  end
end
