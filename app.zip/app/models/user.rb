# frozen_string_literal: true

class User < ApplicationRecord
  has_many :orders, dependent: :destroy
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
  validates :phone, presence: true, numericality: true, length: { minimum: 10, maximum: 15 }
  validates :address, presence: true
  validates :full_name, presence: true, length: { minimum: 1, maximum: 30 }
  validates :full_name, format: { with: /\A[^0-9`!@#$%\^&*+_=]+\z/ }
  validates :email, format: { with: /\A\S+@.+\.\S+\z/,
                              message: ' is invalid' }
  enum role: { 'user' => 0, 'admin' => 1 }
end
