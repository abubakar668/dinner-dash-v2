# frozen_string_literal: true

class Order < ApplicationRecord
  has_many :order_items, dependent: :destroy
  belongs_to :user

  before_save :set_final_total

  validates :final_total, presence: true
  validates :phone, presence: true, numericality: true, length: { minimum: 10, maximum: 15 }
  validates :address, presence: true
  validates :status, presence: true

  enum status: { 'ordered' => 0, 'paid' => 1, 'cancelled' => 2, 'completed' => 3 }

  def final_total
    order_items.collect { |order_item| order_item.unit_price * order_item.quantity }.sum
  end

  def set_final_total
    self.final_total = final_total
  end
end
