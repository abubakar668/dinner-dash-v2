# frozen_string_literal: true

class Cart < ApplicationRecord
  has_many :cart_items, dependent: :destroy

  before_save :set_subtotal

  after_commit :destroy_cart_job, on: :create

  validates :subtotal, presence: true, numericality: true
  validates :user_id, presence: true

  def subtotal
    cart_items.collect { |cart_item| cart_item.unit_price * cart_item.quantity }.sum
  end

  def set_subtotal
    self.subtotal = subtotal
  end

  def destroy_cart_job
    CartCleanupJob.set(wait: 1.hour).perform_later(id)
  end
end
