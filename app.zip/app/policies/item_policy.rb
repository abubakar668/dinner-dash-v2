# frozen_string_literal: true

class ItemPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      scope.all
    end
  end

  def index?
    true
  end

  def show?
    true
  end

  def new?
    return false if @user.nil?

    @user&.admin?
  end

  def create?
    return false if @user.nil?

    @user&.admin?
  end

  def update?
    return false if @user.nil?

    @user&.admin?
  end

  def destroy?
    return false if @user.nil?

    @user&.admin?
  end
end
