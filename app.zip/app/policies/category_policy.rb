# frozen_string_literal: true

class CategoryPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      scope.all
    end
  end

  def new?
    return false if @user.nil?

    @user&.admin?
  end

  def create?
    return false if @user.nil?

    @user&.admin?
  end

  def destroy?
    return false if @user.nil?

    @user&.admin?
  end
end
