# frozen_string_literal: true

class CartItemPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      scope.all
    end
  end

  def new?
    return true if @user.nil?

    !@user&.admin?
  end

  def create?
    return true if @user.nil?

    !@user&.admin?
  end

  def update?
    return true if @user.nil?

    !@user&.admin?
  end

  def destroy?
    return true if @user.nil?

    !@user&.admin?
  end

  def show?
    return true if @user.nil?

    !@user&.admin?
  end
end
