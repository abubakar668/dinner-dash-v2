# frozen_string_literal: true

class GuestRegisterSessionController < Devise::RegistrationsController
  after_action :after_login_signup
  include Cartable
end
