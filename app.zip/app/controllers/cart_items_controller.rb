# frozen_string_literal: true

class CartItemsController < ApplicationController
  before_action :set_cart_item, only: %i[update destroy]

  include Creatable

  def update
    authorize @cart_item
    return @cart_items = current_cart.cart_items if @cart_item.update(cart_params)

    flash[:danger] = @cart_item.errors.full_messages.join(', ').to_s
  end

  def destroy
    authorize @cart_item
    return @cart_items = current_cart.cart_items if @cart_item.destroy

    flash[:danger] = @cart_item.errors.full_messages.join(', ').to_s
  end

  private

  def cart_params
    params.require(:cart_item).permit(:item_id, :quantity)
  end

  def set_cart_item
    @cart = current_cart
    @cart_item = @cart.cart_items.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    redirect_to root_url, alert: t(:not_found)
  end
end
