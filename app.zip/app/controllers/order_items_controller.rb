# frozen_string_literal: true

class OrderItemsController < ApplicationController
  def create
    if user_signed_in?
      set_order
      set_orderitem
      save_order
      redirect_to root_path, success: t('order_success_msg')
    else
      redirect_to new_user_session_path, danger: t('signin_first_msg')
    end
  end

  def set_order
    @cart = Cart.find_by(user_id: current_user.id)
    @cart_items = @cart.cart_items
    @order = Order.new(user_id: current_user.id, phone: current_user.phone, address: current_user.address)
  end

  def set_orderitem
    @cart_items.each do |cart_item|
      @order_item = @order.order_items.new(quantity: cart_item.quantity, total: cart_item.total,
                                           unit_price: cart_item.unit_price, item_id: cart_item.item.id)
    end
  end

  def save_order
    ActiveRecord::Base.transaction do
      destroy_cart if @order.save!
    rescue ActiveRecord::RecordInvalid
      flash[:danger] = @order.errors.full_messages.join(', ').to_s
    end
  end
end
