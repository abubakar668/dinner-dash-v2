# frozen_string_literal: true

class ItemsController < ApplicationController
  before_action :set_restaurant, except: %i[edit update destroy]
  before_action :set_item, only: %i[edit update destroy]

  def new
    @item = @restaurant.items.build
    authorize @item
  end

  def create
    @item = @restaurant.items.new(item_params)
    authorize @item
    if @item.save
      redirect_to restaurant_path(@restaurant), success: t('Item_success_msg')
    else
      flash[:danger] = @item.errors.full_messages.join(', ').to_s
      render 'new'
    end
  end

  def edit
    authorize @item
  end

  def index
    @items = Item.all
  end

  def update
    authorize @item
    return redirect_to restaurant_path(@item.restaurant_id), info: t('Item_update_msg') if @item.update(item_params)

    flash[:danger] = @item.errors.full_messages.join(', ').to_s
    render 'edit'
  end

  def destroy
    authorize @item
    return redirect_to restaurant_path(@item.restaurant_id), danger: t('Item_destroy_msg') if @item.destroy

    redirect_to restaurant_path(@item.restaurant_id), danger: t('Item_destroy_failure_msg')
  end

  private

  def set_restaurant
    @restaurant = Restaurant.find(params[:restaurant_id])
  rescue ActiveRecord::RecordNotFound
    redirect_to root_url, alert: t(:not_found)
  end

  def set_item
    @item = Item.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    redirect_to root_url, alert: t(:not_found)
  end

  def item_params
    params.require(:item).permit(:title, :description, :price, :status, :image, category_ids: [])
  end
end
