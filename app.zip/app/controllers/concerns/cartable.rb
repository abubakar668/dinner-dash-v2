# frozen_string_literal: true

module Cartable
  extend ActiveSupport::Concern

  def after_login_signup
    update_cart
    ActiveRecord::Base.transaction do
      @guest_cart_items.each do |guest_cart_item|
        cart_item = CartItem.create!(
          quantity: guest_cart_item.quantity,
          item_id: guest_cart_item.item_id,
          cart_id: guest_cart_item.cart_id,
          total: guest_cart_item.total,
          unit_price: guest_cart_item.unit_price
        )
        cart_item.save!
        guest_cart_item.destroy!
      end
    end
  end

  def update_cart
    @cart = Cart.find_by(user_id: current_user&.id)
    @session_cart = Cart.find_by(user_id: browser_session.to_s)
    if @cart.nil?
      nil_case_update
    else
      guest_cart_item_update
    end
  end

  def guest_cart_item_update
    ActiveRecord::Base.transaction do
      @cart.update!(subtotal: @cart.subtotal)
      @guest_cart_items = CartItem.where(cart_id: @session_cart&.id)
      @guest_cart_items.each do |guest_cart_item|
        guest_cart_item.update!(cart_id: @cart&.id)
      end
    end
  end

  def nil_case_update
    @session_cart&.update(user_id: current_user&.id, subtotal: @session_cart&.subtotal)
    @guest_cart_items = CartItem.where(cart_id: @session_cart&.id)
  end
end
