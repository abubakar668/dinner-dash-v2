# frozen_string_literal: true

module Indexable
  extend ActiveSupport::Concern

  def index
    @orders = if current_user.role == 'admin'
                admin_orders
              elsif params[:status]
                orders_of_params
              else
                all_orders.where(user_id: current_user.id).order('created_at ASC')
              end
  end

  def admin_orders
    params[:status] ? all_orders.where(status: params[:status]) : all_orders.all.order('created_at ASC')
  end

  def all_orders
    Order.includes(:order_items)
  end

  def orders_of_params
    all_orders.where(user_id: current_user.id, status: params[:status]).order('created_at ASC')
  end
end
