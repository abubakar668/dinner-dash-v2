# frozen_string_literal: true

module Creatable
  extend ActiveSupport::Concern

  def create
    @restaurant_id = current_cart&.cart_items&.first&.item&.restaurant_id
    check_cartitem
  end

  def save_cart
    return unless @cart_product.nil?

    @cart_item = @cart.cart_items.new(cart_params)
    return session[:cart_id] = @cart.id if @cart_item.save

    flash[:danger] = @cart_item.errors.full_messages.join(', ').to_s
  end

  def cart_product
    @cart = current_cart
    @cart_product = @cart.cart_items.find_by(item_id: cart_params[:item_id].to_i)
  end

  def check_cartitem
    if @restaurant_id == params[:cart_item][:restaurant_id].to_i || @restaurant_id.nil?
      cart_product
      save_cart
    else
      flash[:danger] = t('restaurants_overlap_msg')
      redirect_to restaurant_path(params[:cart_item][:restaurant_id])
    end
  end
end
