# frozen_string_literal: true

class GuestSessionController < Devise::SessionsController
  after_action :after_login_signup
  include Cartable
end
