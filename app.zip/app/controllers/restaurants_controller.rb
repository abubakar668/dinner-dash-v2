# frozen_string_literal: true

class RestaurantsController < ApplicationController
  before_action :set_restaurant, only: %i[show edit update destroy]

  def index
    @restaurants = Restaurant.includes(:items).all
    authorize @restaurants
  end

  def new
    @restaurant = Restaurant.new
    authorize @restaurant
  end

  def edit
    authorize @restaurant
  end

  def create
    @restaurant = Restaurant.new(restaurant_params)
    authorize @restaurant
    return redirect_to restaurants_path, success: t('Restaurant_success_msg') if @restaurant.save

    flash[:danger] = @restaurant.errors.full_messages.join(', ').to_s
    render 'new'
  end

  def update
    authorize @restaurant
    return redirect_to restaurants_path, info: t('Restaurant_update_msg') if @restaurant.update(restaurant_params)

    flash[:danger] = @restaurant.errors.full_messages.join(', ').to_s
    render 'edit'
  end

  def show
    @items = if params[:category]
               Item.joins(:item_categories).where(restaurant_id: @restaurant.id,
                                                  item_categories: { category_id: params[:category] })
             else
               @restaurant.items
             end
    @cart_item = current_cart.cart_items.new
  end

  def destroy
    authorize @restaurant
    return redirect_to restaurants_path, danger: t('Restaurant_destroy_msg') if @restaurant.destroy

    redirect_to restaurants_path, danger: t('Restaurant_destroy_failure_msg')
  end

  private

  def set_restaurant
    @restaurant = Restaurant.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    redirect_to root_url, alert: t(:not_found)
  end

  def restaurant_params
    params.require(:restaurant).permit(:name, :description, :image)
  end
end
