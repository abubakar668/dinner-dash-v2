# frozen_string_literal: true

class OrdersController < ApplicationController
  before_action :set_order, only: %i[show edit update]

  include Indexable

  def edit
    authorize @order
  end

  def update
    authorize @order
    return redirect_to orders_path, info: t('order_update_msg') if @order.update(order_params)

    render 'edit', danger: t('order_update_failure_msg')
  end

  def show; end

  private

  def set_order
    @order = Order.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    redirect_to root_url, alert: t(:not_found)
  end

  def order_params
    params.require(:order).permit(:status)
  end
end
