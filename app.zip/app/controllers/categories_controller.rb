# frozen_string_literal: true

class CategoriesController < ApplicationController
  before_action :set_category, only: %i[destroy]

  def new
    @category = Category.new
    authorize @category
  end

  def create
    @category = Category.new(category_params)
    authorize @category
    return redirect_to restaurants_path, success: t('Categoty_success_msg') if @category.save

    flash[:danger] = @category.errors.full_messages.join(', ').to_s
    render 'new'
  end

  def destroy
    authorize @category
    return redirect_to restaurants_path, danger: t('Category_destroy_msg') if @category.destroy

    redirect_to restaurants_path, danger: t('Category_destroy_failure_msg')
  end

  private

  def category_params
    params.require(:category).permit(:name)
  end

  def set_category
    @category = Category.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    redirect_to root_url, alert: t(:not_found)
  end
end
