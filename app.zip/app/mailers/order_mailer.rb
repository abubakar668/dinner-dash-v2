# frozen_string_literal: true

class OrderMailer < ApplicationMailer
  default from: 'Muhammad Abubakar <abubakarkhalid637@gmail.com>'
  def confirmation(order)
    @order = order
    @user = User.find_by(id: @order.user_id)
    mail(to: @user.email, subject: 'Order Placed!')
  end
end
