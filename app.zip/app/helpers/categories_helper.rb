# frozen_string_literal: true

module CategoriesHelper
  def all_categories
    Category.all
  end

  def all_category_names
    Category.pluck(:name)
  end
end
