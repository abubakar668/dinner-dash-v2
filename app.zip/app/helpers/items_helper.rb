# frozen_string_literal: true

module ItemsHelper
  def show_categories
    Category.order(:name)
  end
end
