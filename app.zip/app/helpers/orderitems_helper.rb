# frozen_string_literal: true

module OrderitemsHelper
end
