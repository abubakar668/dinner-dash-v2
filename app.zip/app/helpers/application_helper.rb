# frozen_string_literal: true

module ApplicationHelper
  def browser_session
    request.session[:session_id]
  end

  def session_id
    session[:user_id] = if user_signed_in?
                          current_user.id
                        else
                          browser_session.to_s
                        end
  end

  def current_cart
    Cart.find_or_create_by!(user_id: session[:user_id])
  end

  def destroy_cart
    current_cart.destroy
  end
end
