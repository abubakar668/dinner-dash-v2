# frozen_string_literal: true

module RestaurantsHelper
  def total_quantity
    current_cart.cart_items.pluck(:quantity).sum
  end
end
