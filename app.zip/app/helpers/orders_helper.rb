# frozen_string_literal: true

module OrdersHelper
  def order_items(order)
    OrderItem.where(order_id: order.id)
  end

  def order_status
    Order.statuses.reject { |x| x == 'cart' }.map { |key, _value| [key.humanize, key] }
  end
end
