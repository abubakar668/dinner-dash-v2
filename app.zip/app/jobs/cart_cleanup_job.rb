# frozen_string_literal: true

class CartCleanupJob < ApplicationJob
  queue_as :default

  def perform(cart_id)
    cart = Cart.find(cart_id)
    cart_user_id = cart.user_id
    cart.destroy if cart_user_id.to_i.to_s != cart_user_id
  end
end
